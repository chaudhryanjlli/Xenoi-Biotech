HOME STILLS = frame 120, the same frame used on the secondary pages.
home-phone.webp   720x1280 portrait  (58 KB)  -> phones and tablets held upright
home-tablet.webp  1600x900 landscape (65 KB)  -> phones and tablets held sideways
No darkening is baked in: the site's CSS adds the same dark overlay as the secondary pages.
Copy both into the site's bg/ folder, replacing any earlier files with the same names.
